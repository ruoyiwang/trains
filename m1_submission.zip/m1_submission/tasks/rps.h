

void rpsClient ();
void rpsServer();
void playtRPS();
