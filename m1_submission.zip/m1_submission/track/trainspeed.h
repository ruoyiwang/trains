#ifndef __TRAIN_SPEED__
#define __TRAIN_SPEED__

void init_train_speed(int train_num, int* train_speeds);

#endif
