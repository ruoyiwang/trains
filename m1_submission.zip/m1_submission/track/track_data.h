/* THIS FILE IS GENERATED CODE -- DO NOT EDIT */

#ifndef __TRACK_DATA__
#define __TRACK_DATA__

#include "track_node.h"

// The track initialization functions expect an array of this size.
#define TRACK_MAX 144

void init_tracka(track_node *track);
void init_trackb(track_node *track);

#endif
